জনি ভাই — Android APK Build Project

এই ZIP-এ Android Studio project এবং GitHub Actions cloud-build workflow আছে।

গুরুত্বপূর্ণ:
- এই কাজের পরিবেশে Android SDK/Gradle build environment নেই, তাই এখানে APK binary compile করা যায়নি।
- Cloud build চালাতে project-টি GitHub repository-তে upload করতে হবে। এরপর Actions tab থেকে "Build Joni Bhai APK" workflow চালালে APK artifact পাওয়া যাবে।
- GitHub account-এ সাইন ইন ও repository upload করার কাজ ব্যবহারকারীকে নিজে করতে হবে; পাসওয়ার্ড/OTP কাউকে দেবেন না।

Game prototype currently 2D, portrait, offline WebView wrapper.
